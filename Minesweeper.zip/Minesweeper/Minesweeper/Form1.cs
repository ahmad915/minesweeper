﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using WMPLib;
namespace Minesweeper
{
    public partial class Form1 : Form
    {
        WMPLib.WindowsMediaPlayer player=new WMPLib.WindowsMediaPlayer();
        int size = 9;
        Button [][] btns;
        int[][] array;
        int count = 0;
        int score = 1;
        public Form1()
        {
            InitializeComponent();
            player.URL="sound.mp3";
            player.controls.stop();
          
        }
        private void make_button()
        {
           
        }
     /*   private void button2_Click(object sender, EventArgs e)
        {
            flowLayoutPanel1.Controls.Clear();

            btns = new Button[size][];
            for (int i = 0; i < size; i++)
            {
                btns[i] = new Button[size];
                for (int j = 0; j < size; j++)
                {
                    btns[i][j] = new Button();
                    btns[i][j].Width = 20;
                    btns[i][j].Height = 20;
                    btns[i][j].BackColor = Color.Black;
                    btns[i][j].ForeColor = Color.Black;
                    // flowLayoutPanel1.Controls.Add(btns[i][j]);
                }
            }

        }*/
        void create_array(int size)
        {
            array = new int[size][];
            for(int i=0;i<size;i++)
            {
                array[i] = new int[size];
                for(int j=0;j<size;j++)
                {
                    array[i][j]=0;
                }
            }
        }
        void put_mines()
        {
                for(int j=0;j<size;j++)
                {
                    Random var1 = new Random();
                    Random var2 = new Random();
                    int rnum = var1.Next(0, 9);
                    int cnum = var2.Next(0, 9);
                    if(array[rnum][cnum]==-1)
                    {
                        j--;
                    }
                    else
                    {
                        array[rnum][cnum] = -1;
                    }
                }
        }

        void Rec_Call(int ri,int ci)
        {
            if((ri==-1)||(ci==-1))
            {
                return;
            }
            if((ri==-1)||(ci==9))
            {
                return;
            }
            if((ri==9)||(ci==9))
            {
                return;
            }
            if((ri==9)||(ci==-1))
            {
                return;
            }
            if(array[ri][ci]!=0)
            {
                show(ri,ci);
                array[ri][ci] = 10;
                return ;
            }
            else
            {
                array[ri][ci] = 10;
                Rec_Call(ri-1,ci-1);
                Rec_Call(ri-1,ci);
                Rec_Call(ri-1,ci+1);
                Rec_Call(ri,ci-1);
                Rec_Call(ri,ci+1);
                Rec_Call(ri+1,ci-1);
                Rec_Call(ri+1,ci);
                Rec_Call(ri+1,ci+1);
                show(ri, ci);
            }
        }
        void show(int rw, int cl)
        {
            btns[rw][cl].ForeColor = Color.Transparent;
            btns[rw][cl].BackColor = Color.Gray;
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    if (array[i][j] == 10)
                        score++;
                }
            }
            textBox3.Text = score.ToString();
            if (score == 72)
            {
                MessageBox.Show("You win!");
                this.Close();
            }
            else
                score = 1;
        }
        void nbr_hood(int ri,int ci)
        {
            if (ri != 0 && ci != 0)
            {
                if (array[ri - 1][ci - 1] == -1)
                {
                    count++;
                }
            }

               if(ri!=0)
               {
                   if (array[ri - 1][ci] == -1)
                   {
                       count++;
                   }
               }
          if(ri!=0&&ci!=size-1)
          {
              if (array[ri - 1][ci + 1] == -1)
              {
                  count++;
              }
          }
            if(ci!=0)
            {
                    if(array[ri][ci-1]==-1)
                    {
                          count++;
                     }
            }
           if(ci!=size-1)
           {
               if (array[ri][ci + 1] == -1)
               {
                   count++;
               }
           }
           if(ri!=size-1&&ci!=0)
           {
               if (array[ri + 1][ci - 1] == -1)
               {
                   count++;
               }
           }
           if(ri!=size-1)
           {
               if (array[ri + 1][ci] == -1)
               {
                   count++;
               }
           }
            if(ri!=size-1&&ci!=size-1)
            {
                if (array[ri + 1][ci + 1] == -1)
                {
                    count++;
                }
            }
           
            array[ri][ci] = count;
            count = 0;
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {

        }

        private void button24_Click(object sender, EventArgs e)
        {

        }

        private void button23_Click(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
            player.controls.play();
            flowLayoutPanel1.Controls.Clear();
            create_array(size);
            put_mines();
            btns = new Button[size][];
            for (int i = 0; i < size; i++)
            {
                btns[i] = new Button[size];
                for (int j = 0; j < size; j++)
                {
                    btns[i][j] = new Button();
                    btns[i][j].Width = 35;
                    btns[i][j].Height = 35;
                    btns[i][j].BackColor = Color.Aqua;
                    btns[i][j].ForeColor = Color.Aqua;
                    if (array[i][j] != -1)
                        nbr_hood(i, j);
                  //  btns[i][j].Text = ((i*9) +j).ToString();
                    btns[i][j].Text = array[i][j].ToString();
                    flowLayoutPanel1.Controls.Add(btns[i][j]);
                }
            }
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
            flowLayoutPanel1.Width = 375;
            flowLayoutPanel1.Height = 375;

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
  
            
 
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e) //Ok button
        {
            int rindex;
            int cindex;
            rindex = int.Parse(textBox1.Text);
            cindex = int.Parse(textBox2.Text);

            rindex--;
            cindex--;
            if (array[rindex][cindex] == -1)
            {
                MessageBox.Show("Game Over");
                this.Close();
            }
            Rec_Call(rindex, cindex);
            
          //  score = 0;
           // btns[rindex][cindex].BackColor = Color.Chocolate;

        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0";
            textBox2.Text = "0";

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
